# python academic examples
Work in Progress

Python 2.7

Run command linke 'python test_sort.py' 

the that command can test file in /examples/sort/bubble.py